#ifndef FORMS_H
#define FORMS_H


class Forms
{
public:
    Forms();
};

#endif // FORMS_H