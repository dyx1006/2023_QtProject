# traffic-light-qt
A game that shows how the traffic light works (homework for 2023 programming practice class)
