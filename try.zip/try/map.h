#ifndef MAP_H
#define MAP_H
#include <QPixmap>

class Map
{
public:
    //构造函数
    Map();
public:
    //地图图片对象
    QPixmap m_map1;
};

#endif // MAP_H
