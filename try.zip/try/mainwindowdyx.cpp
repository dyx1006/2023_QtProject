#include "mainwindowdyx.h"
#include "dialog2.h"
#include "mainscene.h"
#include "ui_mainwindowdyx.h"
#include "ui_dialog2.h"
#include "ui_dialog.h"
#include "ui_dialog3.h"
#include "ui_simulatewindow.h"
#include "ui_endwindow.h"

#include <QDebug>
// #include <QDialog>
#include <QPushButton>
#include <QTimer>

//int MainWindowDyx::counter

MainWindowDyx::MainWindowDyx(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindowDyx)
{
    ui->setupUi(this);
    setWindowFlags(windowFlags()&~Qt::WindowMaximizeButtonHint);
    ui->toolBar->hide();
    this->setCentralWidget(dialogStart);
    //    central_widget=1;
    
    
    // 所有的信号和槽
    //0.计时器与计数器
    connect(Timer,&QTimer::timeout,[=]()
    {
        static double counter=0;
        if(reset_timer==true)
        {
            reset_timer=false;
            counter=0;
        }
        double simulate_speed = dialogSet->windowSimulate->simulate_speed;
        // counter是static类型，一直累加，代表总启动时长，因此用全局变量msec来存放这一次定时器的启动时长
        dialogSet->windowSimulate->msec=counter;

//        dialogSet->windowSimulate->m_Timer.setInterval(int(GAME_RATE*simulate_speed));

        dialogSet->windowSimulate->ui->lableShowSimulateRate->
                setText(QString("×")+QString::number(simulate_speed,'f',1));
        //100ms发出一次信号，所以+=0.1*。。。
        dialogSet->windowSimulate->ui->lableShowTime->
                setText(QString::number(counter+=0.1*simulate_speed,'f',1));
        dialogSet->windowSimulate->ui->lableShowPassCar->
                setText(QString::number(this->dialogSet->windowSimulate->pass_car_number));

        dialogSet->windowSimulate->updateCarSpeedAndTimer();
    });
    //1.mainwindowdyx**********************************************************
//    connect(ui->actionHeavyFlow,&QAction::triggered,[=]()
//    {
//        dialogSet->windowSimulate->traffic_flow=700;
//    });
//    connect(ui->actionNormalFlow,&QAction::triggered,[=]()
//    {
//        dialogSet->windowSimulate->traffic_flow=1000;
//    });
//    connect(ui->actionLightFlow,&QAction::triggered,[=]()
//    {
//        dialogSet->windowSimulate->traffic_flow=1300;
//    });

    connect(ui->actionNew,&QAction::triggered,[=]()
    {
        dialogSet->windowSimulate->judge_stop=0;
        Timer->stop();
        int ans = QMessageBox::question(this, tr("Warning"), tr("是否结束模拟并返回主界面？"));
        if(ans==QMessageBox::Yes)
        {
            Timer->stop();
            delete dialogSet->windowSimulate;

            ui->toolBar->hide();

            this->takeCentralWidget();
            this->setCentralWidget(dialogStart);
            //            central_widget=1;

            dialogStart->show();
        }
        else
        {
            dialogSet->windowSimulate->judge_stop=1;
            Timer->start();
        }
    });

    connect(ui->actionChangeParameter,&QAction::triggered,[=]()
    {
        dialogSet->windowSimulate->judge_stop=0;
        Timer->stop();
        int ans = QMessageBox::question(this, tr("Warning"), tr("是否结束模拟并修改参数？"));
        if(ans==QMessageBox::Yes)
        {
            Timer->stop();
            delete dialogSet->windowSimulate;

            ui->toolBar->hide();

            this->takeCentralWidget();
            this->setCentralWidget(dialogSet);
            //            central_widget=2;

            dialogSet->show();
        }
        else
        {
            dialogSet->windowSimulate->judge_stop=1;
            Timer->start();
        }
    });

    connect(ui->actionStopSimulate,&QAction::triggered,[=]()
    {
        dialogSet->windowSimulate->judge_stop=0;
        Timer->stop();
    });
    connect(ui->actionContinueSimulate,&QAction::triggered,[=]()
    {
        dialogSet->windowSimulate->judge_stop=1;
        Timer->start();
    });
    
    // 展示统计数据页面
    connect(ui->actionEndSimulate,&QAction::triggered,[=]()
    {
        dialogSet->windowSimulate->judge_stop=0;
        Timer->stop();
        int ans = QMessageBox::question(this, tr("Warning"), tr("是否结束模拟？"));
        if(ans==QMessageBox::Yes)
        {
            delete dialogSet->windowSimulate;
            ui->toolBar->hide();

            this->takeCentralWidget();
            this->setCentralWidget(windowEnd);
            int pass_car_number=dialogSet->windowSimulate->pass_car_number;
            double msec=dialogSet->windowSimulate->msec;
            windowEnd->ui->lableShowPassCar->setText(QString::number(pass_car_number));
            windowEnd->ui->lableShowTime->setText(QString::number(msec));

            int tmp=pass_car_number*10/msec;
            int remainder=tmp%5;
            tmp-=remainder;
            char evaluation;
            switch (tmp)
            {
            case 10:
                evaluation='A';
                break;
            case 5:
                evaluation='B';
                break;
            case 0:
                evaluation='C';
                break;
            default:
                evaluation='S';
            }
            windowEnd->ui->lableParameterEvaluation->setText(QString(evaluation));

            windowEnd->show();

        }
        else
        {
            dialogSet->windowSimulate->judge_stop=1;
            Timer->start();
        }
    });

    // 调整倍速
    connect(ui->action_0_5Speed,&QAction::triggered,[=]()
    {
        dialogSet->windowSimulate->simulate_speed=0.5;
    });
    connect(ui->action_1Speed,&QAction::triggered,[=]()
    {
        dialogSet->windowSimulate->simulate_speed=1;
    });
    connect(ui->action_2Speed,&QAction::triggered,[=]()
    {
        dialogSet->windowSimulate->simulate_speed=2;
    });
    connect(ui->action_10Speed,&QAction::triggered,[=]()
    {
        dialogSet->windowSimulate->simulate_speed=10;
    });
    
    
    
    //2.dialogStart**********************************************************
    connect(dialogStart->ui->pushButton,&QPushButton::clicked,[=]()
    {
        this->takeCentralWidget();
        this->setCentralWidget(dialogSet);
        //        central_widget=2;
        
        dialogSet->show();
    });
    connect(dialogStart->ui->pushButton_help,&QPushButton::clicked,[=]()
    {
        this->takeCentralWidget();
        this->setCentralWidget(dialogHelp);
        //        central_widget=3;
        
        dialogHelp->show();
    });
    connect(dialogStart->ui->pushButton_exit,&QPushButton::clicked,this,&QMainWindow::close);
    
    //3.dialogSet**********************************************************
    connect(dialogSet->ui->btnLogin_ ,&QPushButton::clicked,[=]()
    {
        if(dialogSet->ui->txtstraightgreen_->text()!=""&&
                dialogSet->ui->txtleftgreen_->text()!=""&&
                dialogSet->ui->txtrightstraight_->text()!=""&&
                dialogSet->ui->txtleftstraight_->text()!=""&&
                dialogSet->ui->txtturnright_->text()!=""&&
                dialogSet->ui->txtturnleft_->text()!="")
        {
            // 开启工具栏
            ui->toolBar->show();
            
            // 定时器
            reset_timer=true;
            Timer->start(100);
            
            
            // 设置中心窗口
            this->takeCentralWidget();
            dialogSet->windowSimulate = new SimulateWindow;
            dialogSet->windowSimulate->ui->lableShowTime->setText(QString::number(0));
            dialogSet->windowSimulate->ui->lableShowPassCar->setText(QString::number(0));
            this->setCentralWidget(dialogSet->windowSimulate);
            //            central_widget=4;
            
            dialogSet->on_btnLogin_clicked();
            
            
            
            //            // 计时器每秒发一次信号
            //            dialogSet->windowSimulate->timer_simulate->start(1000);
            //            qDebug()<<"press button"<<endl;
            //            if(dialogSet->windowSimulate->timer_simulate->isActive())
            //            {
            //                dialogSet->windowSimulate->hide();
            //            }
        }
        else
        {
            QMessageBox::warning(this, tr("Warning"), tr("Haven't input all numbers yet!"), QMessageBox::Yes);
        }
    });
    
    //4.dialogHelp**********************************************************
    connect(dialogHelp->ui->pushButton_3 ,&QPushButton::clicked,[=]()
    {
        this->takeCentralWidget();
        this->setCentralWidget(dialogStart);
        //        central_widget=1;
        
        dialogStart->show();
    });

    //5.windowEnd**********************************************************
    connect(windowEnd->ui->pushButtonBackMainWindow,&QPushButton::clicked,[=]()
    {
        this->takeCentralWidget();
        this->setCentralWidget(dialogStart);
        //        central_widget=1;

        dialogStart->show();
    });
    connect(windowEnd->ui->pushButtonExit,&QPushButton::clicked,this,&QMainWindow::close);
}

MainWindowDyx::~MainWindowDyx()
{
    delete ui;
    //    delete dialogSet;
    //    delete dialogStart;
    //    delete dialogHelp;
}
